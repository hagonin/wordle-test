# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

A Next.js app that automatically plays the Votee Wordle API's `/random` puzzle. The browser runs the solver and game loop; `POST /api/guess` is a stateless per-guess proxy to the Votee API — there is no server-side game session. See `docs/overview.md` for scope/terminology and `docs/architecture.md` for the full file-ownership table before making non-trivial changes.

## Commands

- `npm run dev` — start the dev server
- `npm test` — run the full Vitest suite (offline, stubbed `fetch`, no network or `.env` needed)
- `npm test -- tests/solver.test.ts` — run a single test file
- `npm test -- tests/solver.test.ts -t "name substring"` — run a single test by name
- `npm run lint` — ESLint (`eslint-config-next` core-web-vitals + typescript)
- `npm run build` / `npm run start` — production build / serve
- No `.env` file is required to install, test, build, or run. `VOTEE_API_URL` is optional server-side config (see `.env.example`); an invalid value throws when a guess is made.

## Architecture

Game flow: Browser (`src/app/page.tsx`) runs the solver → `postGuess` → `POST /api/guess` → `guessRandom` → Votee `GET /random`. Each `POST /api/guess` is independent, which is what lets the page pause between guesses and render rows as they arrive.

| Concern | File |
|---|---|
| Page, game loop, pause between guesses | `src/app/page.tsx` |
| Page state machine | `src/lib/game-state.ts` (`gameReducer`) |
| End-of-game text | `src/lib/outcome.ts` (`describeOutcome`) |
| Browser→route call, reply validation | `src/lib/guess-client.ts` (`postGuess`) |
| Route: request validation, rate limit, error mapping | `src/app/api/guess/route.ts` |
| Per-IP limiter | `src/lib/rate-limit.ts` |
| Votee adapter | `src/lib/votee-api.ts` (`guessRandom`) |
| API host config | `src/lib/config.ts` (`voteeApiUrl`) |
| Scoring, filtering, next-guess choice | `src/lib/solver.ts` (`solve`, `score`) |
| Word lists (pinned sources in file headers) | `src/lib/words.ts`, `src/lib/allowed-guesses.ts` |

Tests mirror these modules under `tests/`, with a shared fixture in `tests/helpers/`.

**Solver algorithm** (`src/lib/solver.ts`): deterministic constraint filtering followed by a distinct-partition heuristic — not full entropy maximization or minimax. Feedback per letter is `absent`/`present`/`correct`, encoded as a base-3 digit packed into one integer (0–242 for five letters) so candidate comparisons are numeric, not string arrays. The first guess is always fixed (currently `crane`) so games stay deterministic. After filtering, answer-list candidates are preferred over allowed-guesses candidates, with ties broken by list order. Full writeup, complexity (`O(M^2 * L^2)` per guess), and design-pattern inventory: `docs/technical-analysis.md`.

## Hard boundaries (enforced by tests — do not casually change)

- **No `@/` path alias anywhere**, source or tests — only relative imports, so Vitest runs with no config file. Enforced by `tests/bundle-boundaries.test.ts`.
- **Only `src/lib/votee-api.ts` touches the network on the server.** The solver is pure and network-free; it receives a guess function as a parameter, which is how tests drive it with a stub.
- **`src/app/page.tsx` is the only file allowed to import the solver/word-list modules as values, and only via a dynamic `import()`.** Every other file that references them (`outcome.ts`, `game-state.ts`, `guess-client.ts`) may only type-import. This keeps the word lists out of the initial page bundle. Enforced by `tests/bundle-boundaries.test.ts`.
- **Answer-list words must sort before allowed-guesses words**, and the word lists themselves are pinned by length/order/checksum in `tests/word-lists.test.ts`. Changing a list is a deliberate act that updates that test.
- **The solver reproduces Votee's "naive" scoring**, where a repeated letter is marked `present` without counting occurrences (unlike real Wordle). Do not "correct" this to real Wordle scoring — it would eliminate the true answer against Votee's actual feedback. See `docs/decisions.md#the-solver-copies-the-apis-naive-scoring`.
- **Games must stay deterministic**: the same seed and word lists always produce the same guesses. The solve-rate thresholds in `tests/solver.test.ts` have intentionally little slack — a shifted number there means solver behavior changed, not flakiness.
- **Both hops validate replies independently**: the server validates Votee's response, and the browser validates the route's response, so neither side trusts the other's JSON.

## Docs

Rationale-heavy docs live under `docs/` — read the relevant one before changing behavior it covers:

- `docs/overview.md` — purpose, scope, terminology (seed, slot, feedback, candidates, stop reason)
- `docs/architecture.md` — file-ownership table and the boundaries above, in full, with reasoning
- `docs/decisions.md` — why each non-obvious choice was made, and what was rejected instead
- `docs/technical-analysis.md` — solver algorithm, complexity, runtime workflow, design patterns
- `docs/operations.md` — configuration, rate-limit behavior, Votee API quirks, deployment target (Vercel)
- `docs/DESIGN.md` — UI rules for the page; read before touching markup, CSS Modules, or copy
- `docs/benchmarks.md` — dated solver performance measurements, reproduced by `npm test`

`plans/` holds working design/phase notes and is gitignored — it exists locally but most of it is intentionally untracked, not published documentation.
